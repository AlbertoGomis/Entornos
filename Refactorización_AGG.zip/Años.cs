﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Fecha
{
    class Años
    {
        private int dia;
        private int mes;
        private int año;

        public int Dia { get => dia; set => dia = value; }
        public int Mes { get => mes; set => mes = value; }
        public int Año { get => año; set => año = value; }
    }
}
